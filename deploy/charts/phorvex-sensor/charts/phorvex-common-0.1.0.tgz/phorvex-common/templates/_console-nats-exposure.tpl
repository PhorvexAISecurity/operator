{{/* console-nats-exposure.yaml, moved from the manager chart: the manager chart renders it unless
phorvex.console.separate, and deploy/charts/phorvex-console renders it when it is. */}}
{{- define "phorvex-common.console.nats-exposure" -}}
{{- if and .Values.phorvex.console.natsExposure.clientResponse.enabled (not (and .Values.phorvex.console.enabled .Values.phorvex.console.natsExposure.enabled)) }}
{{- fail "natsExposure.clientResponse requires console.enabled and natsExposure.enabled" }}
{{- end }}
{{- if and .Values.phorvex.console.enabled .Values.phorvex.console.natsExposure.enabled }}
apiVersion: v1
kind: Namespace
metadata:
  name: phorvex-nats-exposure-fixture
  labels:
    phorvex.ai/nats-exposure-fixture: "true"
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ include "phorvex.fullname" . }}-console-nats-fixture
  namespace: phorvex-nats-exposure-fixture
rules:
- apiGroups: [""]
  resources: ["pods"]
  verbs: ["get", "create", "delete"{{- if .Values.phorvex.console.natsExposure.clientResponse.enabled }}, "list", "patch"{{- end }}]
- apiGroups: [""]
  resources: ["configmaps"]
  verbs: ["get", "create", "delete"]
- apiGroups: [""]
  resources: ["pods/log"]
  verbs: ["get"]
{{- if .Values.phorvex.console.natsExposure.clientResponse.enabled }}
- apiGroups: [""]
  resources: ["services"]
  verbs: ["get", "create", "delete"]
- apiGroups: ["discovery.k8s.io"]
  resources: ["endpointslices"]
  verbs: ["list"]
- apiGroups: ["apps"]
  resources: ["deployments"]
  verbs: ["get", "create", "delete"]
- apiGroups: ["apps"]
  resources: ["replicasets"]
  verbs: ["get", "list", "delete"]
- apiGroups: ["policy"]
  resources: ["poddisruptionbudgets"]
  verbs: ["get", "create", "delete"]
- apiGroups: ["phorvex.ai"]
  resources: ["phorvexpolicies"]
  verbs: ["get", "list", "create", "delete"]
- apiGroups: ["amtd.r6security.com"]
  resources: ["adaptivemovingtargetdefenses"]
  verbs: ["get", "list", "delete"]
- apiGroups: ["networking.k8s.io"]
  resources: ["networkpolicies"]
  verbs: ["get", "list", "delete"]
{{- end }}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ include "phorvex.fullname" . }}-console-nats-fixture
  namespace: phorvex-nats-exposure-fixture
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: {{ include "phorvex.fullname" . }}-console-nats-fixture
subjects:
- kind: ServiceAccount
  name: {{ include "phorvex.attackServiceAccountName" . }}
  namespace: {{ .Release.Namespace }}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ include "phorvex.fullname" . }}-console-nats-read
  namespace: nats
rules:
- apiGroups: [""]
  resources: ["pods", "services", "configmaps"]
  verbs: ["get"]
- apiGroups: ["apps"]
  resources: ["statefulsets"]
  verbs: ["get"]
- apiGroups: ["discovery.k8s.io"]
  resources: ["endpointslices"]
  verbs: ["list"]
- apiGroups: [""]
  resources: ["pods/portforward"]
  verbs: ["create"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ include "phorvex.fullname" . }}-console-nats-read
  namespace: nats
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: {{ include "phorvex.fullname" . }}-console-nats-read
subjects:
- kind: ServiceAccount
  name: {{ include "phorvex.attackServiceAccountName" . }}
  namespace: {{ .Release.Namespace }}
{{- end }}
{{- end -}}
