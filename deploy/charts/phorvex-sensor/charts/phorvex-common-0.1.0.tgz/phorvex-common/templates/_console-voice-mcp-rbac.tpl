{{/* console-voice-mcp-rbac.yaml, moved from the manager chart: the manager chart renders it unless
phorvex.console.separate, and deploy/charts/phorvex-console renders it when it is. */}}
{{- define "phorvex-common.console.voice-mcp-rbac" -}}
{{- if and .Values.phorvex.console.enabled .Values.phorvex.console.voiceMCPLive.enabled }}
{{- $full := include "phorvex.fullname" . }}
{{- $uid := required "console.voiceMCPLive.deploymentUID required" .Values.phorvex.console.voiceMCPLive.deploymentUID }}
{{- $prefix := printf "phorvex-voice-mcp-%s-" (trunc 32 (sha256sum $uid)) }}
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ $full }}-console-voice-mcp-source
  namespace: voice
rules:
- apiGroups: [""]
  resources: ["configmaps"]
  resourceNames: ["voice-mcp-tool-policy", {{ .Values.phorvex.console.voiceMCPLive.sourceConfigMapName | quote }}]
  verbs: ["get"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ $full }}-console-voice-mcp-source
  namespace: voice
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: {{ $full }}-console-voice-mcp-source
subjects:
- kind: ServiceAccount
  name: {{ include "phorvex.attackServiceAccountName" . }}
  namespace: {{ .Release.Namespace }}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ $full }}-console-mcp-server-source
  namespace: mcp
rules:
- apiGroups: [""]
  resources: ["configmaps"]
  resourceNames: [{{ .Values.phorvex.console.voiceMCPLive.mcpSourceConfigMapName | quote }}]
  verbs: ["get"]
- apiGroups: ["discovery.k8s.io"]
  resources: ["endpointslices"]
  verbs: ["list"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ $full }}-console-mcp-server-source
  namespace: mcp
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: {{ $full }}-console-mcp-server-source
subjects:
- kind: ServiceAccount
  name: {{ include "phorvex.attackServiceAccountName" . }}
  namespace: {{ .Release.Namespace }}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ $full }}-console-voice-mcp-journal
  namespace: {{ default .Release.Namespace .Values.phorvex.operatorNamespace | quote }}
rules:
- apiGroups: [""]
  resources: ["configmaps"]
  resourceNames: [{{ printf "%s1" $prefix | quote }}, {{ printf "%s2" $prefix | quote }}]
  verbs: ["get"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ $full }}-console-voice-mcp-journal
  namespace: {{ default .Release.Namespace .Values.phorvex.operatorNamespace | quote }}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: {{ $full }}-console-voice-mcp-journal
subjects:
- kind: ServiceAccount
  name: {{ include "phorvex.attackServiceAccountName" . }}
  namespace: {{ .Release.Namespace }}
{{- end }}
{{- end -}}
