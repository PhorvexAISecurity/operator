# Math Lab experiment 88aa343c-e701-4d37-ad62-22b88bb66125

**Telegram 18e300921b28: P-FEA-006 1.0 1.2 1.5**

- Parameter: `P-FEA-006` CHi cost ceiling (spec.slo.costCeiling)
- Policy: `phorvex-staging-demo/demo-api-defense`; mode: REPLAY (decision mechanism only)
- Replay binary: source `b1ef9ccdb258f0a94b0dad575a17cc3a4c25cab0`, image `sha256:d208a9a53acd16cc146dce4c72b26d7614620862f2e1cecc1f526259033a1903`
- Cohort: 64 recorded ticks, digest list `sha256:ba3dbb8c916bb8f5c92ea5b525f6c905d9a0e158c998650f20200c6eed50535c`
- Comparison status: **MATCHED_REPLAY**
- Control eligible (baseline reproduced exactly): 64; matched per arm: {'control': 64, 'v1.0': 64, 'v1.2': 64, 'v1.5': 64}
- Excluded control ticks: none

## Hypothesis

Requested from Telegram by 1385091105

## Headline metrics

| Arm | Value | Metric | Estimate | 95% interval | n | Kind |
|---|---|---|---|---|---|---|
| control | recorded 1.2 | M-P21 | 0 | [0, 0.05662] | 64 | PROCESS |
| control | recorded 1.2 | M-P04 | 0 | [0, 0.01962] | 192 | PROCESS |
| control | recorded 1.2 | M-P25 | 0 | [0, 0] | 64 | ESTIMATED_MODEL |
| control | recorded 1.2 | M-P26 | 0 | [0, 0] | 64 | PROCESS |
| control | recorded 1.2 | M-P28 | 0 | [0, 0] | 64 | ESTIMATED_MODEL |
| v1.0 | 1.0 | M-P21 | 0 | [0, 0.05662] | 64 | PROCESS |
| v1.0 | 1.0 | M-P04 | 0 | [0, 0.01962] | 192 | PROCESS |
| v1.0 | 1.0 | M-P25 | 0 | [0, 0] | 64 | ESTIMATED_MODEL |
| v1.0 | 1.0 | M-P26 | 0 | [0, 0] | 64 | PROCESS |
| v1.0 | 1.0 | M-P28 | 0 | [0, 0] | 64 | ESTIMATED_MODEL |
| v1.0 | 1.0 | M-P25 (diff vs control) | 0 | [0, 0] | 64 | ESTIMATED_MODEL |
| v1.0 | 1.0 | M-P26 (diff vs control) | 0 | [0, 0] | 64 | PROCESS |
| v1.0 | 1.0 | M-P28 (diff vs control) | 0 | [0, 0] | 64 | ESTIMATED_MODEL |
| v1.0 | 1.0 | M-P21 (diff vs control) | 0 | [0, 0] | 64 | PROCESS |
| v1.2 | 1.2 | M-P21 | 0 | [0, 0.05662] | 64 | PROCESS |
| v1.2 | 1.2 | M-P04 | 0 | [0, 0.01962] | 192 | PROCESS |
| v1.2 | 1.2 | M-P25 | 0 | [0, 0] | 64 | ESTIMATED_MODEL |
| v1.2 | 1.2 | M-P26 | 0 | [0, 0] | 64 | PROCESS |
| v1.2 | 1.2 | M-P28 | 0 | [0, 0] | 64 | ESTIMATED_MODEL |
| v1.2 | 1.2 | M-P25 (diff vs control) | 0 | [0, 0] | 64 | ESTIMATED_MODEL |
| v1.2 | 1.2 | M-P26 (diff vs control) | 0 | [0, 0] | 64 | PROCESS |
| v1.2 | 1.2 | M-P28 (diff vs control) | 0 | [0, 0] | 64 | ESTIMATED_MODEL |
| v1.2 | 1.2 | M-P21 (diff vs control) | 0 | [0, 0] | 64 | PROCESS |
| v1.5 | 1.5 | M-P21 | 0 | [0, 0.05662] | 64 | PROCESS |
| v1.5 | 1.5 | M-P04 | 0 | [0, 0.01962] | 192 | PROCESS |
| v1.5 | 1.5 | M-P25 | 0 | [0, 0] | 64 | ESTIMATED_MODEL |
| v1.5 | 1.5 | M-P26 | 0 | [0, 0] | 64 | PROCESS |
| v1.5 | 1.5 | M-P28 | 0 | [0, 0] | 64 | ESTIMATED_MODEL |
| v1.5 | 1.5 | M-P25 (diff vs control) | 0 | [0, 0] | 64 | ESTIMATED_MODEL |
| v1.5 | 1.5 | M-P26 (diff vs control) | 0 | [0, 0] | 64 | PROCESS |
| v1.5 | 1.5 | M-P28 (diff vs control) | 0 | [0, 0] | 64 | ESTIMATED_MODEL |
| v1.5 | 1.5 | M-P21 (diff vs control) | 0 | [0, 0] | 64 | PROCESS |

## What this does and does not show

- Replay measures immediate decision sensitivity on recorded states; it does not observe defense, SLO impact or future-state effects.
- After an arm diverges from the control, later recorded states no longer follow from that arm.
- ScopedOutcomes (reporting-only) is excluded from the exact baseline comparison.
- M-S01 (verified defense rate) and M-D02..M-D09 (observed disruption) are UNAVAILABLE in replay. No row here is a defense or safety result.
- ESTIMATED_MODEL rows are model quantities; PROCESS rows are decision-mechanism counts.

_Generated 2026-11-01T21:29:40.810110Z. Raw rows: sweep_results.csv, candidate_gate_trace.csv, decision_funnel.csv, cost_truth.csv; replay.jsonl is authoritative._
